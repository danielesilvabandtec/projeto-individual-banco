package br.com.bandtec.projetoindividualbanco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoIndividualBancoApplicationTests {

	@Test
	void contextLoads() {
	}

}
