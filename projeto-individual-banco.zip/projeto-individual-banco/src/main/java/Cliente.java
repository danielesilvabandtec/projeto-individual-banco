import java.util.ArrayList;
import java.util.List;

public class Cliente {
    private String nome;
    private String cpf;
    private String endereco;
    private boolean status;
    List<Conta> contas;

    public Cliente(String nome, String cpf, String endereco, boolean status) {
        this.nome = nome;
        this.cpf = cpf;
        this.endereco = endereco;
        this.status = status;
        this.contas = new ArrayList<Conta>();
    }
    public void adicionarConta(Conta c){
        contas.add(c);
    }
    public double valorTotalContas (){
        double valortotal = 0.0;
        for (Conta conta : contas){
            valortotal += conta.getRenderValor();
        }
        return valortotal;
    }
    public void exibirContas(){
        for(Conta conta : contas){
            System.out.println(conta);
        }
    }

    @Override
    public String toString() {
        return "\nCliente" +
                "\nNome: " + nome  +
                "\nCPF: " + cpf +
                "\nEndereco: " + endereco +
                "\nStatus: " + status ;
    }
}
