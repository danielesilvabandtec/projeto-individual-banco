public class ContaPoupanca extends Conta{
    private double saldo;

    public ContaPoupanca(String agencia, String numeroConta, double saldo) {
        super(agencia, numeroConta);
        this.saldo = saldo;
    }
    public void depositar(){
        saldo += 50;

    }
    public void sacar(){
        saldo -= 50;

    }

    public double getRenderValor() {
        return (saldo * 0.25) + saldo;
    }

    @Override
    public String toString() {
        return "\nConta Poupança" +
                "\nSaldo: " + saldo +
                "\nValor Total rendido: " + getRenderValor();

    }
}

