import java.util.ArrayList;
import java.util.List;

public class Banco {
    private String nome;
    private String cnpj;
    List<Cliente> clientes;

    public Banco(String nome, String cnpj) {
        this.nome = nome;
        this.cnpj = cnpj;
        this.clientes = new ArrayList<Cliente>();
    }

    public void exibirDadosBanco(){
        System.out.println(toString());
        for(Cliente cliente : clientes){
            System.out.println(cliente);
        }

    }
    public void adicionarConta(Cliente cli){
        clientes.add(cli);
    }
    public void deletarCliente(Cliente cli){
        clientes.remove(cli);
    }

    @Override
    public String toString() {
        return "\nBanco" +
                "\nNome: " + nome +
                "\nCNPJ: " + cnpj ;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public List<Cliente> getClientes() {
        return clientes;
    }

    public void setClientes(List<Cliente> clientes) {
        this.clientes = clientes;
    }
}
