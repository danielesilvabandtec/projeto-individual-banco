package br.com.bandtec.projetoindividualbanco;

public interface Rendimento {
    public double getRenderValor();
}
