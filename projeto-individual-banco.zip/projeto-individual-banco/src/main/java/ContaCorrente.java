public class ContaCorrente extends Conta {
    private double saldo;

    public ContaCorrente(String agencia, String numeroConta, double saldo) {
        super(agencia, numeroConta);
        this.saldo = saldo;
    }
    public void depositar(){
        saldo += 50;

    }
    public void sacar(){
        saldo -= 50;

    }

    public double getRenderValor() {
        return (saldo * 0.10) + saldo;
    }

    @Override
    public String toString() {
        return "\nConta Corrente" +
                "\nSaldo: " + saldo +
                "\nValor Total rendido: " + getRenderValor();

    }
}

