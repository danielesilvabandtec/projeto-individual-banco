public interface Rendimento {
    public double getRenderValor();
}
